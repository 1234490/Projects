/* global $ */
/*
 * Retrieves the information from the element and prepends it to the table.
 */
function displayInformation(element) {
  $("tbody").prepend(`
    <tr>
      <td><img src="${element.imgGold}"></td>
      <td>${element.name}</td>
      <td>${element.cardId}</td>
      <td>${element.dbfId}</td>
      <td>${element.cardSet}</td>
      <td>${element.type}</td>
      <td>${element.faction}</td>
      <td>${element.rarity}</td>
      <td>${element.cost}</td>
      <td>${element.attack}</td>
      <td>${element.health}</td>
      <td>${element.text}</td>
      <td>${element.flavor}</td>
      <td>${element.artist}</td>
      <td>${element.collectible}</td>
      <td>${element.elite}</td>
      <td>${element.race}</td>
      <td>${element.playerClass}</td>
    </tr>
  `);
}

$(function() {
  var originalURL = "https://omgvamp-hearthstone-v1.p.rapidapi.com/cards/"
  
  $("button").click(function() {
    var newURL = originalURL + $("input").val(); // Append requested name.
    
    var settings = {
    	"async": true,
    	"crossDomain": true,
    	"url": newURL,
    	"method": "GET",
    	"headers": {
    		"x-rapidapi-host": "omgvamp-hearthstone-v1.p.rapidapi.com",
    		"x-rapidapi-key": "173ff14ademsh867cc3171de522ap13bb4bjsn09906c4bb6f5"
    	}
    }
    
    $.ajax(settings).done(function (response) { // No response if invalid.
    	response.forEach(function(element) {
    	  displayInformation(element);
      });
    });
  });
});